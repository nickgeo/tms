#!/bin/bash
aws ec2 start-instances --instance-ids i-0d9b19161e7174785