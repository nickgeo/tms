#!/bin/bash
sudo systemctl start webodm && sleep 15
sudo systemctl status webodm